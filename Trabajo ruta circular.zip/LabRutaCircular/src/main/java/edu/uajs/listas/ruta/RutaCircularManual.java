package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.List;

public class RutaCircularManual implements RutaCircular {

    private Nodo primero;
    private Nodo actual;
    private int tamanio;

    @Override
    public void agregar(Parada c) {
        Nodo nuevo = new Nodo(c);

        if (primero == null) {
            nuevo.siguiente = nuevo;
            nuevo.anterior = nuevo;
            primero = nuevo;
            actual = nuevo;
        } else {
            Nodo ultimo = primero.anterior;
            nuevo.anterior = ultimo;
            nuevo.siguiente = primero;
            ultimo.siguiente = nuevo;
            primero.anterior = nuevo;
        }
        tamanio++;
    }

    @Override
    public Parada actual() {
        return actual == null ? null : actual.dato;
    }

    @Override
    public Parada siguiente() {
        if (actual == null) return null;
        actual = actual.siguiente;
        return actual.dato;
    }

    @Override
    public Parada anterior() {
        if (actual == null) return null;
        actual = actual.anterior;
        return actual.dato;
    }

    @Override
    public Parada saltar(int n) {
        if (actual == null) return null;

        n = n % tamanio;

        for (int i = 0; i < n; i++) {
            actual = actual.siguiente;
        }
        for (int i = 0; i > n; i--) {
            actual = actual.anterior;
        }
        return actual.dato;
    }

    @Override
    public Parada eliminarActual() {
        if (actual == null) return null;

        if (tamanio == 1) {
            primero = null;
            actual = null;
            tamanio = 0;
            return null;
        }

        Nodo previo = actual.anterior;
        Nodo proximo = actual.siguiente;

        previo.siguiente = proximo;
        proximo.anterior = previo;

        if (actual == primero) {
            primero = proximo;
        }

        actual = proximo;
        tamanio--;
        return actual.dato;
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    @Override
    public int tiempoTotal() {
        if (primero == null) return 0;

        int total = 0;
        Nodo aux = primero;
        do {
            total += aux.dato.minutos();
            aux = aux.siguiente;
        } while (aux != primero);
        return total;
    }

    @Override
    public List<String> nombresDesdeActual() {
        List<String> nombres = new ArrayList<>();
        if (actual == null) return nombres;
        Nodo aux = actual;
        do {
            nombres.add(aux.dato.nombre());
            aux = aux.siguiente;
        } while (aux != actual);
        return nombres;
    }
}
